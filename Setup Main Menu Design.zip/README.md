
  # Setup Main Menu Design

  This is a code bundle for Setup Main Menu Design. The original project is available at https://www.figma.com/design/rtTwxqBj5hSrIi2ckfeeMp/Setup-Main-Menu-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  