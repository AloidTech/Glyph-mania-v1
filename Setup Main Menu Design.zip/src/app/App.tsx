import { useState } from "react";
import {
  X,
  SpeakerHigh,
  SpeakerX,
  Faders,
  MusicNote,
} from "@phosphor-icons/react";
import { motion, AnimatePresence } from "motion/react";

// ─── Global overrides for range input chrome ──────────────────────────────────
const RANGE_STYLES = `
  input[type="range"] {
    -webkit-appearance: none;
    appearance: none;
    height: 3px;
    border-radius: 9999px;
    outline: none;
    cursor: pointer;
    border: none;
  }
  input[type="range"]::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 14px;
    height: 14px;
    border-radius: 50%;
    background: var(--color-accent);
    cursor: pointer;
    box-shadow: 0 0 8px var(--color-accent-glow);
    transition: transform 0.12s ease, box-shadow 0.12s ease;
  }
  input[type="range"]::-webkit-slider-thumb:hover {
    transform: scale(1.25);
    box-shadow: 0 0 14px var(--color-accent-glow);
  }
  input[type="range"]::-moz-range-thumb {
    width: 14px;
    height: 14px;
    border-radius: 50%;
    background: var(--color-accent);
    cursor: pointer;
    border: none;
    box-shadow: 0 0 8px var(--color-accent-glow);
  }
`;

// ─── Ambient glyph ring ────────────────────────────────────────────────────────
function AmbientGlyph() {
  const spoke = (i: number, total: number, r1: number, r2: number) => {
    const a = (i / total) * 2 * Math.PI - Math.PI / 2;
    return {
      x1: 400 + r1 * Math.cos(a),
      y1: 400 + r1 * Math.sin(a),
      x2: 400 + r2 * Math.cos(a),
      y2: 400 + r2 * Math.sin(a),
    };
  };
  const starPts = (n: number, rOut: number, rIn: number) =>
    Array.from({ length: n * 2 })
      .map((_, i) => {
        const a = (i / (n * 2)) * 2 * Math.PI - Math.PI / 2;
        const r = i % 2 === 0 ? rOut : rIn;
        return `${400 + r * Math.cos(a)},${400 + r * Math.sin(a)}`;
      })
      .join(" ");

  return (
    <svg
      viewBox="0 0 800 800"
      aria-hidden="true"
      className="absolute pointer-events-none select-none"
      style={{
        width: "min(860px, 88vw)",
        height: "min(860px, 88vw)",
        left: "50%",
        top: "50%",
        transform: "translate(-50%, -50%)",
        opacity: 0.052,
        color: "var(--color-accent)",
      }}
    >
      {/* Rings */}
      {[390, 365, 338, 292, 248, 172, 88, 14].map((r, i) => (
        <circle
          key={r}
          cx="400" cy="400" r={r}
          fill="none"
          stroke="currentColor"
          strokeWidth={i === 2 || i === 0 ? 0.9 : 0.4}
          strokeDasharray={i === 1 || i === 3 ? "3 7" : undefined}
        />
      ))}
      <circle cx="400" cy="400" r="4" fill="currentColor" />

      {/* 16 outer spokes */}
      {Array.from({ length: 16 }).map((_, i) => (
        <line key={`s${i}`} {...spoke(i, 16, 248, 338)} stroke="currentColor" strokeWidth="0.5" />
      ))}
      {/* 8 inner spokes */}
      {Array.from({ length: 8 }).map((_, i) => (
        <line key={`is${i}`} {...spoke(i, 8, 88, 172)} stroke="currentColor" strokeWidth="0.4" />
      ))}

      {/* Octagram */}
      <polygon points={starPts(8, 200, 88)} fill="none" stroke="currentColor" strokeWidth="0.65" />

      {/* Diamond tick marks at outer ring */}
      {Array.from({ length: 8 }).map((_, i) => {
        const a = (i / 8) * 2 * Math.PI - Math.PI / 2;
        const cx = 400 + 338 * Math.cos(a);
        const cy = 400 + 338 * Math.sin(a);
        const s = 6.5;
        return (
          <polygon
            key={`d${i}`}
            points={`${cx},${cy - s} ${cx + s},${cy} ${cx},${cy + s} ${cx - s},${cy}`}
            fill="currentColor"
          />
        );
      })}

      {/* Half-tick marks between spokes */}
      {Array.from({ length: 32 }).map((_, i) => {
        if (i % 2 === 0) return null;
        const a = (i / 32) * 2 * Math.PI - Math.PI / 2;
        return (
          <line
            key={`t${i}`}
            x1={400 + 334 * Math.cos(a)} y1={400 + 334 * Math.sin(a)}
            x2={400 + 342 * Math.cos(a)} y2={400 + 342 * Math.sin(a)}
            stroke="currentColor" strokeWidth="0.55"
          />
        );
      })}
    </svg>
  );
}

// ─── Corner sigil ──────────────────────────────────────────────────────────────
function CornerSigil({ pos }: { pos: "tl" | "tr" | "bl" | "br" }) {
  const edgeStyle: Record<string, React.CSSProperties> = {
    tl: { top: 20, left: 20 },
    tr: { top: 20, right: 20 },
    bl: { bottom: 20, left: 20 },
    br: { bottom: 20, right: 20 },
  };
  const rot = { tl: 0, tr: 90, bl: 270, br: 180 }[pos];

  return (
    <svg
      viewBox="0 0 100 100"
      aria-hidden="true"
      className="absolute pointer-events-none select-none"
      style={{
        ...edgeStyle[pos],
        width: 68,
        height: 68,
        opacity: 0.08,
        color: "var(--color-accent)",
        transform: `rotate(${rot}deg)`,
      }}
    >
      <circle cx="50" cy="50" r="46" fill="none" stroke="currentColor" strokeWidth="1" />
      <circle cx="50" cy="50" r="35" fill="none" stroke="currentColor" strokeWidth="0.5" strokeDasharray="2.5 4" />
      <line x1="50" y1="4" x2="50" y2="96" stroke="currentColor" strokeWidth="0.5" />
      <line x1="4" y1="50" x2="96" y2="50" stroke="currentColor" strokeWidth="0.5" />
      <line x1="17.6" y1="17.6" x2="82.4" y2="82.4" stroke="currentColor" strokeWidth="0.4" />
      <line x1="82.4" y1="17.6" x2="17.6" y2="82.4" stroke="currentColor" strokeWidth="0.4" />
      {/* Arrowhead pointing inward */}
      <polygon points="50,8 57,28 50,23 43,28" fill="currentColor" />
      <circle cx="50" cy="50" r="5.5" fill="none" stroke="currentColor" strokeWidth="1" />
      <circle cx="50" cy="50" r="2" fill="currentColor" />
      {Array.from({ length: 12 }).map((_, i) => {
        const a = (i / 12) * 2 * Math.PI - Math.PI / 2;
        const r1 = i % 3 === 0 ? 37 : 41;
        return (
          <line
            key={i}
            x1={50 + r1 * Math.cos(a)} y1={50 + r1 * Math.sin(a)}
            x2={50 + 46 * Math.cos(a)} y2={50 + 46 * Math.sin(a)}
            stroke="currentColor" strokeWidth={i % 3 === 0 ? "1" : "0.5"}
          />
        );
      })}
    </svg>
  );
}

// ─── Ornamental divider ────────────────────────────────────────────────────────
function RuneDivider() {
  return (
    <div className="flex items-center gap-3 w-full">
      <div className="flex-1 h-px" style={{ background: "linear-gradient(to right, transparent, rgba(201,162,39,0.22))" }} />
      <svg viewBox="0 0 20 20" width="11" height="11" aria-hidden="true" style={{ color: "var(--color-accent)", opacity: 0.55, flexShrink: 0 }}>
        <polygon points="10,1.5 18.5,10 10,18.5 1.5,10" fill="none" stroke="currentColor" strokeWidth="1.4" />
        <circle cx="10" cy="10" r="2.8" fill="currentColor" />
      </svg>
      <div className="flex-1 h-px" style={{ background: "linear-gradient(to left, transparent, rgba(201,162,39,0.22))" }} />
    </div>
  );
}

// ─── Button system ─────────────────────────────────────────────────────────────
// Per spec: no gradients; hover = soft accent shadow bloom; press = inset shadow

const BTN_BASE: React.CSSProperties = {
  fontFamily: "var(--font-display)",
  letterSpacing: "0.2em",
  fontSize: "0.7rem",
  fontWeight: 700,
  textTransform: "uppercase",
  transition: "box-shadow 0.18s ease, background 0.18s ease",
  cursor: "pointer",
  userSelect: "none",
  display: "block",
  width: "100%",
  textAlign: "center",
  borderRadius: "var(--radius-sm)",
};

function PrimaryButton({ children, onClick }: { children: React.ReactNode; onClick?: () => void }) {
  return (
    <motion.button
      onClick={onClick}
      whileTap={{ scale: 0.975 }}
      style={{
        ...BTN_BASE,
        padding: "0.95rem 2rem",
        background: "var(--color-accent)",
        color: "var(--color-bg)",
        border: "none",
        boxShadow: "0 0 22px var(--color-accent-glow), 0 3px 10px rgba(0,0,0,0.5)",
      }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLButtonElement).style.boxShadow =
          "0 0 38px rgba(201,162,39,0.52), 0 4px 16px rgba(0,0,0,0.55)";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLButtonElement).style.boxShadow =
          "0 0 22px var(--color-accent-glow), 0 3px 10px rgba(0,0,0,0.5)";
      }}
      onMouseDown={(e) => {
        (e.currentTarget as HTMLButtonElement).style.boxShadow =
          "0 0 12px var(--color-accent-glow), inset 0 2px 6px rgba(0,0,0,0.35)";
      }}
      onMouseUp={(e) => {
        (e.currentTarget as HTMLButtonElement).style.boxShadow =
          "0 0 38px rgba(201,162,39,0.52), 0 4px 16px rgba(0,0,0,0.55)";
      }}
    >
      {children}
    </motion.button>
  );
}

function SecondaryButton({ children, onClick }: { children: React.ReactNode; onClick?: () => void }) {
  return (
    <motion.button
      onClick={onClick}
      whileTap={{ scale: 0.975 }}
      style={{
        ...BTN_BASE,
        padding: "0.95rem 2rem",
        background: "var(--color-glass)",
        backdropFilter: "blur(8px)",
        color: "var(--color-accent)",
        border: "1px solid var(--color-glass-border)",
        boxShadow: "0 2px 8px rgba(0,0,0,0.35)",
      }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLButtonElement).style.boxShadow =
          "0 0 22px rgba(201,162,39,0.18), 0 2px 8px rgba(0,0,0,0.35)";
        (e.currentTarget as HTMLButtonElement).style.borderColor =
          "rgba(201,162,39,0.38)";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLButtonElement).style.boxShadow =
          "0 2px 8px rgba(0,0,0,0.35)";
        (e.currentTarget as HTMLButtonElement).style.borderColor =
          "var(--color-glass-border)";
      }}
      onMouseDown={(e) => {
        (e.currentTarget as HTMLButtonElement).style.boxShadow =
          "inset 0 2px 5px rgba(0,0,0,0.4)";
      }}
      onMouseUp={(e) => {
        (e.currentTarget as HTMLButtonElement).style.boxShadow =
          "0 0 22px rgba(201,162,39,0.18), 0 2px 8px rgba(0,0,0,0.35)";
      }}
    >
      {children}
    </motion.button>
  );
}

function GhostButton({ children, onClick }: { children: React.ReactNode; onClick?: () => void }) {
  return (
    <motion.button
      onClick={onClick}
      whileTap={{ scale: 0.97 }}
      style={{
        ...BTN_BASE,
        padding: "0.6rem 2rem",
        background: "transparent",
        color: "var(--color-text-muted)",
        border: "none",
        opacity: 0.65,
        transition: "opacity 0.18s ease",
      }}
      onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.opacity = "1"; }}
      onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.opacity = "0.65"; }}
    >
      {children}
    </motion.button>
  );
}

// Not shown in the menu but defined for completeness (per spec)
function DestructiveButton({ children, onClick }: { children: React.ReactNode; onClick?: () => void }) {
  return (
    <motion.button
      onClick={onClick}
      whileTap={{ scale: 0.975 }}
      style={{
        ...BTN_BASE,
        padding: "0.9rem 2rem",
        background: "var(--color-destructive)",
        color: "#f8ede0",
        border: "none",
        boxShadow: "0 0 18px rgba(192,71,43,0.28), 0 3px 8px rgba(0,0,0,0.5)",
      }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLButtonElement).style.boxShadow =
          "0 0 32px rgba(192,71,43,0.45), 0 4px 12px rgba(0,0,0,0.55)";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLButtonElement).style.boxShadow =
          "0 0 18px rgba(192,71,43,0.28), 0 3px 8px rgba(0,0,0,0.5)";
      }}
      onMouseDown={(e) => {
        (e.currentTarget as HTMLButtonElement).style.boxShadow =
          "inset 0 2px 5px rgba(0,0,0,0.4)";
      }}
      onMouseUp={(e) => {
        (e.currentTarget as HTMLButtonElement).style.boxShadow =
          "0 0 32px rgba(192,71,43,0.45), 0 4px 12px rgba(0,0,0,0.55)";
      }}
    >
      {children}
    </motion.button>
  );
}

// ─── Glass panel primitive ─────────────────────────────────────────────────────
function GlassPanel({
  children,
  className = "",
  style = {},
}: {
  children: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
}) {
  return (
    <div
      className={className}
      style={{
        background: "var(--color-glass)",
        backdropFilter: "blur(8px)",
        WebkitBackdropFilter: "blur(8px)",
        border: "1px solid rgba(255,255,255,0.05)",
        boxShadow: "0 8px 40px rgba(0,0,0,0.55), 0 0 60px rgba(60,20,110,0.12)",
        ...style,
      }}
    >
      {children}
    </div>
  );
}

// ─── Glass card row (settings) ─────────────────────────────────────────────────
function GlassCard({ children }: { children: React.ReactNode }) {
  return (
    <div
      style={{
        background: "rgba(255,255,255,0.03)",
        border: "1px solid rgba(255,255,255,0.055)",
        borderRadius: "var(--radius-sm)",
        padding: "var(--space-md)",
        display: "flex",
        flexDirection: "column",
        gap: "var(--space-sm)",
      }}
    >
      {children}
    </div>
  );
}

// ─── Setting controls ──────────────────────────────────────────────────────────
function SettingSlider({
  label,
  value,
  onChange,
  icon,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  icon: React.ReactNode;
}) {
  return (
    <GlassCard>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "var(--space-sm)" }}>
          <span style={{ color: "var(--color-accent)" }}>{icon}</span>
          <span style={{ fontFamily: "var(--font-body)", fontSize: "1.05rem", color: "var(--color-text-base)" }}>
            {label}
          </span>
        </div>
        <span
          style={{
            fontFamily: "var(--font-display)",
            fontSize: "0.68rem",
            letterSpacing: "0.06em",
            color: "var(--color-text-muted)",
            minWidth: "2.6rem",
            textAlign: "right",
          }}
        >
          {Math.round(value * 100)}%
        </span>
      </div>
      <input
        type="range"
        min="0"
        max="1"
        step="0.01"
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        style={{
          width: "100%",
          background: `linear-gradient(to right,
            rgba(201,162,39,0.8) 0%,
            rgba(201,162,39,0.8) ${value * 100}%,
            rgba(255,255,255,0.1) ${value * 100}%,
            rgba(255,255,255,0.1) 100%)`,
        }}
      />
    </GlassCard>
  );
}

function SettingToggle({
  label,
  value,
  onChange,
  icon,
}: {
  label: string;
  value: boolean;
  onChange: (v: boolean) => void;
  icon: React.ReactNode;
}) {
  return (
    <GlassCard>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "var(--space-sm)" }}>
          <span style={{ color: value ? "var(--color-accent)" : "var(--color-text-muted)", transition: "color 0.25s" }}>
            {icon}
          </span>
          <span style={{ fontFamily: "var(--font-body)", fontSize: "1.05rem", color: "var(--color-text-base)" }}>
            {label}
          </span>
        </div>
        {/* Toggle pill */}
        <button
          onClick={() => onChange(!value)}
          aria-pressed={value}
          aria-label={`${label}: ${value ? "enabled" : "disabled"}`}
          style={{
            position: "relative",
            width: 44,
            height: 24,
            borderRadius: 999,
            border: "none",
            cursor: "pointer",
            flexShrink: 0,
            background: value ? "rgba(201,162,39,0.82)" : "rgba(255,255,255,0.1)",
            boxShadow: value ? "0 0 14px rgba(201,162,39,0.4)" : "inset 0 1px 3px rgba(0,0,0,0.4)",
            transition: "background 0.25s, box-shadow 0.25s",
          }}
        >
          <span
            style={{
              position: "absolute",
              top: 3,
              left: 3,
              width: 18,
              height: 18,
              borderRadius: "50%",
              background: value ? "var(--color-bg)" : "var(--color-text-muted)",
              transform: value ? "translateX(20px)" : "translateX(0)",
              transition: "transform 0.25s ease, background 0.25s",
              display: "block",
            }}
          />
        </button>
      </div>
    </GlassCard>
  );
}

// ─── Icon button (ghost, for modal header) ─────────────────────────────────────
function IconButton({ icon, onClick, label }: { icon: React.ReactNode; onClick: () => void; label: string }) {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      style={{
        background: "transparent",
        border: "none",
        color: "var(--color-text-muted)",
        cursor: "pointer",
        width: 32,
        height: 32,
        borderRadius: "var(--radius-sm)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        transition: "color 0.15s, background 0.15s",
        flexShrink: 0,
      }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLButtonElement).style.color = "var(--color-text-base)";
        (e.currentTarget as HTMLButtonElement).style.background = "rgba(255,255,255,0.06)";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLButtonElement).style.color = "var(--color-text-muted)";
        (e.currentTarget as HTMLButtonElement).style.background = "transparent";
      }}
    >
      {icon}
    </button>
  );
}

// ─── Settings modal ────────────────────────────────────────────────────────────
function SettingsModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [masterVolume, setMasterVolume] = useState(0.8);
  const [sfxVolume, setSfxVolume] = useState(0.6);
  const [sfxEnabled, setSfxEnabled] = useState(true);

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            className="fixed inset-0 z-40"
            style={{ background: "rgba(4,2,10,0.75)" }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            onClick={onClose}
          />

          {/* Modal panel */}
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center"
            style={{ padding: "var(--space-lg)" }}
            initial={{ opacity: 0, scale: 0.94, y: 16 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.94, y: 16 }}
            transition={{ duration: 0.26, ease: [0.16, 1, 0.3, 1] }}
            onClick={(e) => e.stopPropagation()}
          >
            <GlassPanel
              style={{
                width: "100%",
                maxWidth: 430,
                borderRadius: "var(--radius-lg)",
                overflow: "hidden",
                boxShadow: "0 12px 60px rgba(0,0,0,0.75), 0 0 80px rgba(50,20,100,0.2), 0 0 0 1px rgba(201,162,39,0.07)",
              }}
            >
              {/* Header */}
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  padding: "var(--space-md) var(--space-lg)",
                  borderBottom: "1px solid rgba(255,255,255,0.045)",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: "var(--space-sm)" }}>
                  {/* Diamond mark */}
                  <svg viewBox="0 0 20 20" width="13" height="13" aria-hidden="true" style={{ color: "var(--color-accent)", opacity: 0.7 }}>
                    <polygon points="10,1.5 18.5,10 10,18.5 1.5,10" fill="none" stroke="currentColor" strokeWidth="1.5" />
                    <circle cx="10" cy="10" r="2.5" fill="currentColor" />
                  </svg>
                  <h2
                    style={{
                      fontFamily: "var(--font-display)",
                      fontSize: "0.78rem",
                      fontWeight: 600,
                      letterSpacing: "0.2em",
                      color: "var(--color-accent)",
                      textShadow: "0 0 20px rgba(201,162,39,0.3)",
                    }}
                  >
                    SETTINGS
                  </h2>
                </div>
                <IconButton icon={<X size={16} weight="bold" />} onClick={onClose} label="Close settings" />
              </div>

              {/* Setting rows */}
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  gap: "var(--space-sm)",
                  padding: "var(--space-md) var(--space-lg) var(--space-lg)",
                }}
              >
                <SettingSlider
                  label="Master Volume"
                  value={masterVolume}
                  onChange={setMasterVolume}
                  icon={<MusicNote size={17} weight="duotone" />}
                />
                <SettingSlider
                  label="SFX Volume"
                  value={sfxVolume}
                  onChange={setSfxVolume}
                  icon={<Faders size={17} weight="duotone" />}
                />
                <SettingToggle
                  label="SFX Enabled"
                  value={sfxEnabled}
                  onChange={setSfxEnabled}
                  icon={
                    sfxEnabled
                      ? <SpeakerHigh size={17} weight="duotone" />
                      : <SpeakerX size={17} weight="duotone" />
                  }
                />
              </div>
            </GlassPanel>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

// ─── Main menu ─────────────────────────────────────────────────────────────────
export default function App() {
  const [settingsOpen, setSettingsOpen] = useState(false);

  return (
    <>
      <style>{RANGE_STYLES}</style>

      <div
        className="relative w-full flex flex-col items-center justify-center overflow-hidden"
        style={{ background: "var(--color-bg)", minHeight: "100dvh" }}
      >
        {/* Ambient glyph (behind everything) */}
        <AmbientGlyph />

        {/* Corner sigils */}
        <CornerSigil pos="tl" />
        <CornerSigil pos="tr" />
        <CornerSigil pos="bl" />
        <CornerSigil pos="br" />

        {/* Radial depth vignette */}
        <div
          aria-hidden="true"
          className="absolute inset-0 pointer-events-none"
          style={{ background: "radial-gradient(ellipse 55% 65% at 50% 50%, transparent 25%, rgba(4,2,14,0.68) 100%)" }}
        />

        {/* Arcane purple bloom */}
        <div
          aria-hidden="true"
          className="absolute inset-0 pointer-events-none"
          style={{ background: "radial-gradient(ellipse 45% 28% at 50% 0%, rgba(70,25,130,0.11) 0%, transparent 70%)" }}
        />

        {/* ── Centered content stack ── */}
        <div
          className="relative z-10 flex flex-col items-center"
          style={{ gap: 0, width: "100%", maxWidth: 360, padding: "0 var(--space-lg)" }}
        >
          {/* Title block */}
          <motion.div
            className="flex flex-col items-center"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          >
            {/* Top ornament */}
            <svg
              viewBox="0 0 130 22"
              aria-hidden="true"
              style={{ width: 130, height: 22, color: "var(--color-accent)", opacity: 0.5, marginBottom: 14 }}
            >
              <line x1="0" y1="11" x2="46" y2="11" stroke="currentColor" strokeWidth="0.6" />
              <polygon points="65,3 73,11 65,19 57,11" fill="none" stroke="currentColor" strokeWidth="1" />
              <circle cx="65" cy="11" r="2.5" fill="currentColor" />
              <line x1="84" y1="11" x2="130" y2="11" stroke="currentColor" strokeWidth="0.6" />
            </svg>

            {/* H1 title */}
            <h1
              style={{
                fontFamily: "var(--font-display)",
                fontSize: "clamp(2.6rem, 9vw, 5rem)",
                fontWeight: 700,
                letterSpacing: "0.28em",
                marginRight: "-0.28em", /* trim trailing glyph gap */
                color: "var(--color-accent)",
                textShadow: "0 0 36px rgba(201,162,39,0.42), 0 2px 0 rgba(0,0,0,0.85), 0 4px 22px rgba(0,0,0,0.5)",
                lineHeight: 1,
                textAlign: "center",
              }}
            >
              GLYPH MANIA
            </h1>

            {/* Subtitle */}
            <p
              style={{
                fontFamily: "var(--font-body)",
                fontSize: "clamp(0.88rem, 2.2vw, 1.05rem)",
                fontStyle: "italic",
                fontWeight: 300,
                color: "var(--color-text-muted)",
                letterSpacing: "0.07em",
                marginTop: "var(--space-md)",
                textAlign: "center",
              }}
            >
              Inscribe the arcane. Command the unseen.
            </p>
          </motion.div>

          {/* Divider */}
          <motion.div
            className="w-full"
            style={{ marginTop: "var(--space-lg)", marginBottom: "var(--space-lg)" }}
            initial={{ opacity: 0, scaleX: 0.5 }}
            animate={{ opacity: 1, scaleX: 1 }}
            transition={{ duration: 0.5, delay: 0.18, ease: "easeOut" }}
          >
            <RuneDivider />
          </motion.div>

          {/* Button stack – equal width, spaced by --space-md */}
          <motion.div
            className="w-full flex flex-col"
            style={{ gap: "var(--space-md)" }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.28, ease: [0.16, 1, 0.3, 1] }}
          >
            <PrimaryButton onClick={() => {}}>Enter Workshop</PrimaryButton>
            <SecondaryButton onClick={() => setSettingsOpen(true)}>Settings</SecondaryButton>
            <GhostButton onClick={() => {}}>Exit</GhostButton>
          </motion.div>

          {/* Version caption */}
          <motion.p
            style={{
              fontFamily: "var(--font-display)",
              fontSize: "0.6rem",
              letterSpacing: "0.14em",
              color: "rgba(157,143,181,0.28)",
              marginTop: "var(--space-xl)",
              textAlign: "center",
            }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.52 }}
          >
            v0.1.0 — EARLY ACCESS
          </motion.p>
        </div>
      </div>

      <SettingsModal open={settingsOpen} onClose={() => setSettingsOpen(false)} />
    </>
  );
}
